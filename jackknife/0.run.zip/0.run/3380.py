import scipy
import pandas as pd
from scipy.io import arff
from sklearn.model_selection import train_test_split
from keras.layers import Dense
import numpy as np

k = 3380

def deep_model(feature_dim,label_dim):
    from keras.models import Sequential
    from keras.layers import Dense
    model = Sequential()
    print("create model. feature_dim ={}, label_dim ={}".format(feature_dim, label_dim))
    model.add(Dense(4096, activation='relu', input_dim=feature_dim))
    model.add(Dense(2048, activation='relu'))
    model.add(Dense(1024, activation='relu'))
    model.add(Dense(512, activation='relu'))
    model.add(Dense(256, activation='relu'))
    model.add(Dense(label_dim, activation='sigmoid'))
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model
	
def train_deep(X_train,y_train,X_test,y_test,times):
    feature_dim = X_train.shape[1]
    label_dim = y_train.shape[1]
    model = deep_model(feature_dim,label_dim)
    model.summary()
    model.fit(X_train,y_train,batch_size=16, epochs=30,validation_data=(X_test,y_test))
    name = 'my_model'+str(times)+'.h5'
    #model.save(name)
    r = model.predict(X_test)
    rr = r.tolist()
    with open('result.txt','a') as file_handle:
        file_handle.write(str(times))
        file_handle.write('\n')
        file_handle.write(str(rr))
        file_handle.write('\n')
	

data, meta = scipy.io.arff.loadarff('512_400.arff')
df = pd.DataFrame(data)

X = df.iloc[:,14:926].values
y = df.iloc[:,0:14].values



for i in range(k,k+10):
      #j = (3883/10)*(i+1)
      #print(j)
      print(i)
    
      X_train_1 = df.iloc[0:i,14:926].values
      X_train_2 = df.iloc[(i+1):3883,14:926].values
      X_train = np.vstack((X_train_1, X_train_2))
      #print(X_train.shape)
      X_test = df.iloc[i:(i+1),14:926].values
    
      y_train_1 = df.iloc[0:i,0:14].values
      y_train_2 = df.iloc[(i+1):3883,0:14].values
      y_train = np.vstack((y_train_1, y_train_2))
      #print(y_train.shape)
      y_test = df.iloc[i:(i+1),0:14].values
    
      y_train = y_train.astype(np.float64)
      y_test = y_test.astype(np.float64)
      #print(X_test.shape)
      #print(y_test.shape)
    
      train_deep(X_train,y_train,X_test,y_test,i)
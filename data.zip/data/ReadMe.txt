File Description

All files are the info for the 3883 drugs in dataset. 

512_400.arff
dataset in arff file for training, unshuffled. 

512_400_S.arff
dataset in arff file for training, shuffled. 

512_400.csv
512-D fingerprint with 400-D Mashup Vector, without label. 

512_400_atc.csv
512-D fingerprint with 400-D Mashup Vector, with label. 

ATC dataset.xlsx
Original ATC dataset. 

atc-label.txt
label only. 

drug3883_400.csv
400-D Mashup file, Mashup is an algorithm for network embedding. 

fp512.csv
512-D fingerprint file. 

